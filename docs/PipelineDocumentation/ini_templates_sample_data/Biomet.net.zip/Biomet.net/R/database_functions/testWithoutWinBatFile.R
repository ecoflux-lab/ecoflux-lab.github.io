# =====================================================================
# Use this script when testing without running Windows batch file!!
# =====================================================================

args <- c("C:/Biomet.net/R/database_functions", "d:/database_local/Calculation_procedures/TraceAnalysis_ini/DSM/log/DSM_setThirdStageCleaningParameters.R")
source("C:/Biomet.net/R/database_functions/Run_ThirdStage_REddyProc.R")



