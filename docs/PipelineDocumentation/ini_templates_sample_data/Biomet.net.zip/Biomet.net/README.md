# Biomet.net

This repository contains libraries and functions for the EcoFlux Lab Data Cleaning Pipeline. 

For documentation, see <a href="https://ecoflux-lab.github.io/PipelineDocumentation/PipelineDocumentation.html" target="_blank" rel="noopener noreferrer">this webpage</a>. The instructions are continually being updated as the pipeline undergoes further development.
