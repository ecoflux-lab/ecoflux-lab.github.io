set(0,'ShowHiddenHandles','on')
h=get(0,'children');
for i=h
    delete(i);
end
close all;
clear all;
set(0,'ShowHiddenHandles','off')
fclose all;
