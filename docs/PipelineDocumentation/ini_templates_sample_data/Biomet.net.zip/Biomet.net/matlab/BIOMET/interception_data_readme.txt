Interception data readme:

alldave_table1: Table 40 output from your datalogger (half hour info) with the columns as defined in "Intrcpt.fsl"
alldave_table2: Table 42 output from your datalogger (24 hr summary info) with the columns as defined  in "Intrcpt.fsl"
Precip: half hourly precipitation data from our Texas Electronics tipping bucket rain gauge
year, day, hrmin: time from the datalogger network (same as the time from your datalogger) - note this is GMT time with no daylight savings time change (ie 8 hours ahead of PST)
