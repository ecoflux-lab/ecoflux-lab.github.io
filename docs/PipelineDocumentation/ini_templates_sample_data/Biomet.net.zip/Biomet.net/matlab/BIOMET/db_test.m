
c = DB_create('CR','c:\met-data\dbase','paoa',datenum(1996,1,1,0,0,0),datenum(1999,1,1,0,0,0),2,40);
