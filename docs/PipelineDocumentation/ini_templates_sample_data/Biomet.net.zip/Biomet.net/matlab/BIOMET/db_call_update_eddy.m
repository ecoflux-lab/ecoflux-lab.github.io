function x = db_call_update_eddy(pth)

D = 